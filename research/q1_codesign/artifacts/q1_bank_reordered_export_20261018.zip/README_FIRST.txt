Lossless 8-stage activation-bank channel permutation for the exported INT8 QAT CNN.
Model: dn_d10_c32_us_fx_qat. Original model is unchanged.
Place the dn_d10_c32_us_fx_qat folder at:
  C:\fpga\FPGA\build\q1_reviewer_export\dn_d10_c32_us_fx_qat\
CPU equivalence: BSD68 68/68 output images identical; 0 mismatching pixels.
W4 sparse core cycle savings are MODEL PREDICTIONS, not FPGA speedups.
Smart ZYNQ SL PS/DDR/MIO require hardware-specific validation before programming.
